const radius = 10;
const pi = Math.PI;
const areaOfCircle = (radius, pi) => {
    return pi * radius * radius;
};
console.log("The area of circle is:" + areaOfCircle(radius,pi));