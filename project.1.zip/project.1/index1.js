// ========= 1 ==========
// ADDITION
{
let a = 50;
let b = 20;

console.log(a + b);
}

// SUBSTRACTION
{
    let a = 10;
    let b = 20;
    
    console.log(a + b);
}

// DIVISION
{
    let a = 90;
    let b = 10;
    
    console.log(a / b);
}

// MULTIPLICTION
{
    let a = 20;
    let b = 5;
    
    console.log(a * b);
}


// ============ 3 ===========
// function cToF(celsius)
// {
//     var cTemp = celcius;
//     var cToFahr = cTemp * 9/5 + 32;
//     var message = cTemp+'xBOC is' + cToFahr + 'xBOF.';
//     console.log(message);
// }
// function fToC(fahrenheit)
// {
//     var fTemp = fahrenheit;
//     var fToCel = (fTemp - 32) * 5/9;
//     var message = fTemp+'xBOC is' + fToCel + 'xBOF.';
//     console.log(message);
// }




