let P = 1, R = 3, N = 2;
let SI = (P * R * N) / 100;

console.log("Simple Interest =" + SI);