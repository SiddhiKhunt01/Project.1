
let basicSalary = (prompt("Enter the basic salary:"));
let allowances = (prompt("Enter the allowances:"));
let deductions = (prompt("Enter the deductions:"));

// Calculate gross salary
let grossSalary = basicSalary + allowances - deductions;

// Display the gross salary
console.log("The gross salary is: " + grossSalary);