
// =========== 2 ===========
let x = 20;
let y = 40;
console.log("x=",x,"y=",y)

let temp;
temp = x;
x = y;
y = temp;

console.log("After Swaping:")
console.log("x=",x,"y=",y)