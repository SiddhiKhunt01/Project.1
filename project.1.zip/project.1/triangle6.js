function triangleArea (base,height) 
{
    return 0.5 * base * height;
}

let base = 10;
let height = 8;
let area = triangleArea(base, height);

console.log(0.5 * base * height);